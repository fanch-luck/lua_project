PIScript_Screen_version = 1.0
PIScript_Screen_limits = 11

function we_scr_init_0()

end

function we_scr_poll_0()

end

function we_scr_close_0()

end