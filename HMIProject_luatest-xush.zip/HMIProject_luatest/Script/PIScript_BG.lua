PIScript_BG_limits = 11

function we_bg_init()

end

function we_bg_poll()

end